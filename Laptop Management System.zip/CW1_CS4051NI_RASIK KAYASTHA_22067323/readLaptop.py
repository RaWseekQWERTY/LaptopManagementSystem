# Function to display laptop details from text file
def display_file():
    print(
        " -----------------------------------------------------------------------------------------------------------------------")
    print("| LaptopID \t\tLaptop Name \t\t Processor  \t\t Graphics   \t\t Quantity  \t price |")
    print(
        " -----------------------------------------------------------------------------------------------------------------------")
    laptop_file = open("laptop_Data.txt", "r")
    laptopId = 1
    for i in laptop_file:
        print("    ", laptopId, "\t\t", i.replace(",", "\t\t"))
        laptopId += 1
    print(
        "------------------------------------------------------------------------------------------------------------------------")
    print("\n")
    laptop_file.close()

# function to convert file to 2D list
def laptop_2Dlist():
    laptop_file = open("laptop_Data.txt", "r")
    laptop_list = []
    for line in laptop_file:
        line_r = line.replace("\n", " ")
        line_split = line_r.split(',')
        laptop_list.append(line_split)

    laptop_file.close()
    return laptop_list

# Generate counter list from counter text
def bill_counter():
    bill_file = open("Bill_Counter.txt", "r")
    emp_count_list = []

    for line in bill_file:
        line_r = line.replace("\n", " ")
        emp_count_list.append(line_r)
    bill_file.close()
    return emp_count_list
