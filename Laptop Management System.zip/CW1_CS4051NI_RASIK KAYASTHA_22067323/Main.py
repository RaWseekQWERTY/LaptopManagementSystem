import Fnc
import readLaptop
import writeLaptop


# function containing the options menu and main program loop


def front_menu():
    Fnc.welcome_message()
    local_try = True  # For try/except loop
    while local_try:
        loop = True
        while loop:
            print()
            print("1. Add Laptop Stocks.(Purchase From Consumer)")
            print("2. Purchase Laptops.(Sell to Customer)")
            print("3. Exit.")
            print()

            try:
                option_value = int(input("Enter value of the option:"))

                if option_value == 1:

                    employee_details_list = Fnc.employee_details()

                    readLaptop.display_file()

                    laptop_2d_list = readLaptop.laptop_2Dlist()

                    user_laptop_id = Fnc.validate_LaptopId(laptop_2d_list)

                    user_quantity_validation = Fnc.validate_quantity_add()

                    Fnc.add_stock_quantity(
                        user_quantity_validation, user_laptop_id)

                    total_price_add = Fnc.calculate_t_cost(
                        user_quantity_validation, user_laptop_id)

                    ship_comp_name = Fnc.dis_shipping_company()

                    ship_bill_p1 = Fnc.ship_bill_p1(
                        ship_comp_name, employee_details_list)

                    final_ship_bill = Fnc.ship_bill_p2(
                        user_laptop_id, total_price_add, user_quantity_validation, ship_bill_p1)

                    while True:
                        print()
                        print("Do you want to add stock again?")
                        print("1.Yes")
                        print("2. No.")
                        print()

                        choice = input('Enter the id:')

                        if choice == "1":
                            readLaptop.display_file()

                            laptop_2d_list = readLaptop.laptop_2Dlist()

                            user_laptop_id = Fnc.validate_LaptopId(
                                laptop_2d_list)

                            user_quantity_validation = Fnc.validate_quantity_add()

                            Fnc.add_stock_quantity(
                                user_quantity_validation, user_laptop_id)

                            total_price_add = Fnc.calculate_t_cost(
                                user_quantity_validation, user_laptop_id)

                            # ship_comp_name = Fnc.dis_shipping_company()

                            # ship_bill_1 = Fnc.ship_bill_p1(
                            #     ship_comp_name, employee_details_list)

                            final_ship_bill = Fnc.ship_bill_p2(
                                user_laptop_id, total_price_add, user_quantity_validation, ship_bill_p1)

                        elif choice == "2":
                            break

                        else:
                            print("Invalid ID, Please try again")

                    Fnc.ship_grand_total()

                    Fnc.display_cus_bill(final_ship_bill)

                    counter_list_1 = readLaptop.bill_counter()

                    writeLaptop.write_counter_emp(counter_list_1)

                    updated_counter = readLaptop.bill_counter()

                    writeLaptop.write_emp_bill(
                        final_ship_bill, employee_details_list, updated_counter)

                    loop = Fnc.leave_or_return()

                elif option_value == 2:

                    customer_details_list = Fnc.customer_details()
                    Fnc.user_detail(customer_details_list)

                    readLaptop.display_file()

                    laptop_2d_list = readLaptop.laptop_2Dlist()

                    user_laptop_id = Fnc.validate_LaptopId(laptop_2d_list)

                    user_quantity_validation = Fnc.validate_quantity_sub(
                        user_laptop_id, laptop_2d_list)

                    Fnc.sub_stock_quantity(
                        user_quantity_validation, user_laptop_id)

                    total_sale_price = Fnc.calculate_t_price(
                        user_quantity_validation, user_laptop_id)

                    rasik = Fnc.purchase_again(
                        user_laptop_id, user_quantity_validation, total_sale_price)

                    while True:
                        print()
                        print("Do you want buy another laptop?")
                        print("1. Yes")
                        print("2. No.")
                        print()

                        user_choice = input('Enter the id:')

                        if user_choice == "1":
                            readLaptop.display_file()

                            laptop_2d_list = readLaptop.laptop_2Dlist()

                            user_laptop_id = Fnc.validate_LaptopId(
                                laptop_2d_list)

                            user_quantity_validation = Fnc.validate_quantity_sub(
                                user_laptop_id, laptop_2d_list)

                            Fnc.sub_stock_quantity(
                                user_quantity_validation, user_laptop_id)

                            total_sale_price = Fnc.calculate_t_price(
                                user_quantity_validation, user_laptop_id)

                            rasik = Fnc.purchase_again(
                                user_laptop_id, user_quantity_validation, total_sale_price)

                        elif user_choice == "2":
                            break

                        else:
                            print("Invalid ID, Please try again")

                    customer_bill = Fnc.cus_bill()

                    Fnc.display_cus_bill(customer_bill)

                    counter_list_1 = readLaptop.bill_counter()

                    writeLaptop.write_counter_cus(counter_list_1)

                    updated_counter = readLaptop.bill_counter()

                    writeLaptop.write_cus_bill(
                        customer_bill, customer_details_list, updated_counter)

                    loop = Fnc.leave_or_return()

                elif option_value == 3:
                    Fnc.exit_message()
                    loop = False

                else:
                    Fnc.errorInput()
                    loop = True

                local_try = False

            except ValueError:
                print("")
                print("----------------------------------")
                print("Please only enter numeric value!!!")
                print("----------------------------------")
                local_try = True


front_menu()
