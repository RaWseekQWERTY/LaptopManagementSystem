import readLaptop
import writeLaptop

cus_bill_list = []
totals = []

ship_bill_list = []
total_shipping = []


# function to show welcome message
def welcome_message():
    print("-------------------------------------------------")
    print("        Welcome to AI2 Laptop Management System        ")
    print("-------------------------------------------------")
    print("")


# function to exit the screen
def exit_message():
    print()
    print('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++')
    print('         Thank you for using AI2 Laptop Management System          ')
    print('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++')


# function to print error input
def errorInput():
    print()
    print("----------------------------------------------------------")
    print("Invalid Input !!! Please see the options and enter again. ")
    print("----------------------------------------------------------")
    print()


# Function to get customer details
def customer_details():
    customer_details_list = []
    tel_1 = True
    tel_2 = True
    tel_3 = True
    customer_name = ""
    customer_mail = ""
    customer_number = 0
    print("")
    print("----Enter Customer Credentials----")
    print("")

    while tel_1:
        try:
            print("")
            customer_name = str(
                (input("Enter customer name: "))).upper().strip()
            tel_1 = False
        except ValueError:
            print("")
            print("Please try again!!!")
            tel_1 = True

    while tel_2:
        try:
            print("")
            customer_mail = input("Enter customer mail: ")
            tel_2 = False
        except ValueError:
            print("")
            print("Please try again!!!")
            tel_2 = False

    while tel_3:
        try:
            print("")
            customer_number = int(input("Customer phone number: "))
            if len(str(customer_number)) == 10:
                tel_3 = False
            else:
                print("")
                print("Phone number should have 10 characters!!!")
                tel_3 = True

        except ValueError:
            print("")
            print("Please only input numeric value!!")
            tel_3 = True

    print("")
    customer_details_list.append(customer_name)
    customer_details_list.append(customer_mail)
    customer_details_list.append(customer_number)

    return customer_details_list


# Validates the laptop id entered by the user
def validate_LaptopId(laptop_2d_list):
    valid_id = 0
    tel = True
    while tel:
        try:
            valid_id = int(input("Enter the id of the chosen Laptop : "))

            while valid_id <= 0 or valid_id > len(laptop_2d_list):
                print("")
                print("Please provide a valid ID !!!")
                valid_id = int(input("Enter the id of the chosen Laptop : "))

            print("The ID of the chosen Laptop is: ", valid_id)
            print("\n")
            tel = False

        except ValueError:
            print("")
            print("Please only input numeric value!!!")
            tel = True
    return valid_id


# Validates the quantity of the laptop entered by the user
def validate_quantity_sub(user_laptop_id, laptop_list):
    laptop_quantity = 0
    tel1 = True
    while tel1:
        try:
            laptop_quantity = int(input("Enter the quantity of the laptop : "))
            laptop_index = user_laptop_id - 1
            quantity_index = 3
            quantity_value = int(laptop_list[laptop_index][quantity_index])

            while laptop_quantity <= 0 or laptop_quantity > quantity_value:
                print("")
                print(
                    "Please see the available quantity and enter the quantity again!!!")
                laptop_quantity = int(
                    input("Enter the quantity of the laptop : "))
                print("\n")

            tel1 = False

        except ValueError:
            print("")
            print("Please only input numeric values!!!")
            tel1 = True

    return laptop_quantity


# Subtracts the user inserted quantity with the from laptop list quantity
def sub_stock_quantity(user_quantity_validation, user_laptop_id):
    list_q = readLaptop.laptop_2Dlist()
    quantity_index = 3
    laptop_index = user_laptop_id - 1
    q_before_purchase = int(list_q[laptop_index][quantity_index])
    q_purchased = user_quantity_validation
    q_after_purchase = str((q_before_purchase - q_purchased))
    list_q[laptop_index][quantity_index] = q_after_purchase
    writeLaptop.write_in_file(list_q)


# Calculates total price of the quantity purchased
def calculate_t_price(user_quantity_validation, user_laptop_id):
    list_p = readLaptop.laptop_2Dlist()
    laptop_index = user_laptop_id - 1
    user_quantity = user_quantity_validation
    price_index = 4
    single_price = list_p[laptop_index][price_index]
    single_price = int(single_price.replace("$", ""))
    print(str(single_price) + "single")
    total_price = (int(single_price) * int(user_quantity) *
                   0.13) + (int(single_price) * int(user_quantity))
    print(" ")
    return total_price


# Generates bill list
def cus_bill():

    cus_bill_list.append("Grand Total: $" + str(sum(totals)))

    return cus_bill_list


def user_detail(cus_details):
    import datetime as dt
    date_time = dt.datetime.now()
    only_date = date_time.date()
    only_hour = date_time.hour
    only_min = date_time.minute
    time_h_m = str(only_hour) + ":" + str(only_min)

    cus_bill_list.append("Customer Name: " + cus_details[0])
    cus_bill_list.append("Customer Mail: " + cus_details[1])
    cus_bill_list.append("Customer Number: " + str(cus_details[2]))
    cus_bill_list.append("Date of Purchase: " + str(only_date))
    cus_bill_list.append("Time of Purchase: " + time_h_m)
    cus_bill_list.append("\n")


def purchase_again(user_l_id, user_quantity, total_price):
    laptop_list = readLaptop.laptop_2Dlist()
    user_l_id = user_l_id - 1

    global cus_bill_list

    cus_bill_list.append("Laptop Name: " + laptop_list[user_l_id][0])
    cus_bill_list.append("Details: " + laptop_list[user_l_id][1])
    cus_bill_list.append("graphics: " + laptop_list[user_l_id][2])
    cus_bill_list.append("Total Quantity: " + str(user_quantity))

    cus_bill_list.append("Total Cost: $" + str(total_price))
    totals.append(int(total_price))

    cus_bill_list.append("\n")


# Displays the bill list


def display_cus_bill(final_cus_bill):
    print("")
    print("------------------------Bill------------------------")
    for i in final_cus_bill:
        print(i)
    print("----------------------------------------------------")


# -----------------------------------------Add_Stock_Company---------------------------------------------

# Function to take employee details
def employee_details():
    employee_details_list = []
    tel_1 = True
    tel_2 = True
    tel_3 = True
    employee_name = ""
    employee_id = 0
    employee_number = 0

    print("")
    print("----Enter Employee Credentials----")
    print("")

    while tel_1:
        try:
            print("")
            employee_name = (input("Enter employee name: ")).upper()
            tel_1 = False
        except UnicodeError:
            print("")
            print("Please try again!!!")
            tel_1 = True

    while tel_2:
        try:
            print("")
            employee_id = int(input("Enter employee id: "))
            if len(str(employee_id)) == 4:
                tel_2 = False
            else:
                print("")
                print("Employee Id should be 4 character long !!!")
                tel_2 = True

        except ValueError:
            print("")
            print("Please only input numeric value!!!")
            tel_2 = True

    while tel_3:
        try:
            print("")
            employee_number = int(input("Employee phone number: "))
            if len(str(employee_number)) == 10:
                tel_3 = False
            else:
                print("")
                print("Phone numbers should be 10 characters long!!!")
                tel_3 = True

        except ValueError:
            print("")
            print("Please only input numeric values!!!")
            tel_3 = True

    print("")
    employee_details_list.append(employee_name)
    employee_details_list.append(employee_id)
    employee_details_list.append(employee_number)

    return employee_details_list


# Validates the quantity of the laptops entered by the user
def validate_quantity_add():
    laptop_quantity = 0
    tel1 = True
    while tel1:
        try:
            laptop_quantity = int(input("Enter the quantity of the laptop : "))

            while laptop_quantity <= 0 or laptop_quantity > 100:
                readLaptop.display_file()
                print("The maximum quantity that can be added is 100 !!!")
                laptop_quantity = int(
                    input("Enter the quantity of the laptop : "))
                print("\n")

            tel1 = False

        except ValueError:
            print("Please only input numeric values!!!")
            tel1 = True

    return laptop_quantity


# Function to update the new quality to the list and initiate the write function
def add_stock_quantity(user_quantity_validation, user_laptop_id):
    list_q = readLaptop.laptop_2Dlist()
    quantity_index = 3
    laptop_index = user_laptop_id - 1
    q_before_purchase = int(list_q[laptop_index][quantity_index])
    q_purchased = user_quantity_validation
    q_after_purchase = str((q_before_purchase + q_purchased))
    list_q[laptop_index][quantity_index] = q_after_purchase
    writeLaptop.write_in_file(list_q)


# Function to calculate total cost
def calculate_t_cost(user_quantity_validation, user_laptop_id):
    list_p = readLaptop.laptop_2Dlist()
    laptop_index = user_laptop_id - 1
    user_quantity = user_quantity_validation
    price_index = 4
    single_price = list_p[laptop_index][price_index]
    single_price = int(single_price.replace("$", ""))
    # cost price will be lower than selling price
    total_cost = round(0.64 * (single_price * user_quantity))
    print("")

    return total_cost


# Function to display and choose shipping company
def dis_shipping_company():
    ship_name = ""
    tel = True
    print("")
    print("--------------------------------")
    print("-------Shipping-Companies-------")
    print("--------------------------------")
    print("1. Kayastha Shipping Pvt. Ltd.")
    print("2. XieXie Shippers International")
    print("--------------------------------")
    print(" ")
    while tel:
        try:
            shipping_id = input("Choose the shipping company:")
            print(" ")

            if shipping_id == "1":
                ship_name = "Kayastha Shipping Pvt. Ltd."
                tel = False

            elif shipping_id == "2":
                ship_name = "XieXie Shippers International"
                tel = False

            else:
                print("")
                print("Please see the id and type again!!!")
                print("")
                tel = True

        except ValueError:
            print("")
            print("Please input only numbers!!!")
            print("")

            tel = True

    return ship_name


# Function to generate employee bill list (part1)
def ship_bill_p1(ship_comp_name, employee_details_list):
    import datetime as dt
    name_ship_comp = ship_comp_name
    date_time = dt.datetime.now()
    only_date = date_time.date()
    only_hour = date_time.hour
    only_min = date_time.minute
    time_h_m = str(only_hour) + ":" + str(only_min)
    delivery_date = date_time.date() + dt.timedelta(days=3)

    global ship_bill_list

    ship_bill_list.append("Shipping Company: " + name_ship_comp)
    ship_bill_list.append("Date of order: " + str(only_date))
    ship_bill_list.append("Time of order: " + time_h_m)
    ship_bill_list.append("Date of delivery: " + str(delivery_date))
    ship_bill_list.append("Employee Name: " + employee_details_list[0])
    ship_bill_list.append("Employee Id: " + str(employee_details_list[1]))
    ship_bill_list.append("Employee Number: " + str(employee_details_list[2]))
    ship_bill_list.append("\n")

    return ship_bill_list


# Function to generate employee bill list (final)
def ship_bill_p2(user_laptop_id, t_cost, user_quantity, ship_bill):
    listz = readLaptop.laptop_2Dlist()
    laptop_id = user_laptop_id - 1
    shipping_cost = "$" + str(user_quantity * 130)

    ship_bill.append("Laptop Name: " + listz[laptop_id][0])
    ship_bill.append("Details:: " + listz[laptop_id][2])
    ship_bill.append("Quantity: " + str(user_quantity))
    ship_bill.append("Total laptop cost: " + "$" + str(t_cost))
    ship_bill.append("Total shipping cost: " + str(shipping_cost))
    ship_bill.append("\n")

    totals.append(int(t_cost))
    total_shipping.append(int(shipping_cost.replace("$", "")))

    return ship_bill


def ship_grand_total():
    ship_bill_list.append("Shipping Total: $" + str(sum(total_shipping)))
    ship_bill_list.append("Grand Total: $" + str(sum(totals)))

    return ship_bill_list


# Display the employee bill list
def display_emp_bill(ship_bill):
    print("")
    print("------------------------Bill------------------------")
    for i in ship_bill:
        print(i)
    print("----------------------------------------------------")

# Function to take loop value inorder to exit or continue the program


def leave_or_return():
    print("")
    print("--------------------")
    print("Exit or Continue ?")
    print("")
    print("1.Continue")
    print("2.Exit")
    print("--------------------")
    print("")
    loop_value = True
    tel = True
    while tel:
        try:
            print("")
            option = int(input("Enter the option: "))

            if option == 1:
                loop_value = True
                tel = False

            elif option == 2:
                loop_value = False
                tel = False
            else:
                print("")
                print("Please see the option and enter again!!!")
                tel = True

        except ValueError:
            print("Please only input numeric value!!!")
            tel = True

    return loop_value
