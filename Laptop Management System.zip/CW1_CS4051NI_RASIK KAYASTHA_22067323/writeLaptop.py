
# ------------------------------------Purchase Bill
# Writes the bill list to text file
def write_cus_bill(bill_list, customer_detail, cus_counter):
    filename = "Cbill-" + cus_counter[1] + " " + customer_detail[0]
    bill_file = open(filename + ".txt", "w")
    for i in bill_list:
        bill_file.write(i + "\n")
    bill_file.close()

# Writes the updated laptop data list to text file


def write_in_file(updated_list):
    laptop_file = open("laptop_Data.txt", "w")
    for i in updated_list:
        laptop_file.write(str(i[0]) + "," + str(i[1]) + "," +
                          str(i[2]) + "," + str(i[3]) + "," + str(i[4]) + "\n")
    laptop_file.close()

# Writes the customer bill counter to text file


def write_counter_cus(counter_list):
    local_counter = counter_list
    local_counter[1] = str(int(local_counter[1]) + 1)
    counter_file = open("Bill_Counter.txt", "w")
    for i in local_counter:
        counter_file.write(i + "\n")
    counter_file.close()

# ------------------------------------------Add Stock Company Bill

# Update the new count to the counter text file


def write_counter_emp(counter_list):
    local_counter = counter_list
    local_counter[0] = str(int(local_counter[0]) + 1)
    counter_file = open("Bill_Counter.txt", "w")
    for i in local_counter:
        counter_file.write(i + "\n")
    counter_file.close()


# Write employee bill to text file
def write_emp_bill(bill_list, employee_detail, emp_counter):
    filename = "Ebill-" + emp_counter[0] + " " + employee_detail[0]
    bill_file = open(filename + ".txt", "w")
    for i in bill_list:
        bill_file.write(i + "\n")
    bill_file.close()
